package com.example.myapplication

import android.os.Bundle
import android.widget.ImageView
import androidx.activity.ComponentActivity
import com.squareup.picasso.Picasso

class FanActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_fan)

        val imageView: ImageView = findViewById(R.id.fanImage)

        val imageUrl = "https://preview.redd.it/0xjhfignbbla1.jpg?width=640&crop=smart&auto=webp&s=1bb1758adb1cbba5acacec2efd581d0bfd709829"

        Picasso.get()
            .load(imageUrl)
            .placeholder(R.drawable.ic_launcher_foreground) // รูประหว่างโหลด
            .error(R.drawable.ic_launcher_foreground)       // รูปกรณี error
            .into(imageView)
    }
}
