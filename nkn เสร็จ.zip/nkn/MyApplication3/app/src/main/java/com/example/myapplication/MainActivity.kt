package com.example.myapplication

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.myapplication.ui.theme.MyApplicationTheme
import kotlinx.coroutines.delay
import java.time.LocalTime
import java.time.format.DateTimeFormatter

val ThaiFontFamily = FontFamily(
    Font(R.font.nkn) // ฟอนต์จาก res/font/nkn.ttf
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MyApplicationTheme {
                MainScreen()
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen() {
    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "NKN122",
                        color = Color.White,
                        style = TextStyle(
                            fontFamily = ThaiFontFamily,
                            fontSize = 24.sp
                        )
                    )
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color(0xFF3188E5)
                )
            )
        }
    ) { paddingValues ->
        val context = LocalContext.current
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            val currentTime = remember { mutableStateOf(LocalTime.now()) }
            LaunchedEffect(Unit) {
                while (true) {
                    delay(1000)
                    currentTime.value = LocalTime.now()
                }
            }

            // นาฬิกา
            Text(
                text = currentTime.value.format(DateTimeFormatter.ofPattern("HH:mm:ss")),
                style = TextStyle(
                    fontSize = 60.sp,
                    fontFamily = ThaiFontFamily
                ),
                modifier = Modifier.padding(top = 100.dp)
            )

            // ข้อความสวัสดี
            Text(
                text = "สวัสดี",
                style = TextStyle(
                    fontSize = 48.sp,
                    fontFamily = ThaiFontFamily
                ),
                modifier = Modifier.padding(bottom = 16.dp)
            )

            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.padding(bottom = 100.dp)
            ) {
                // ปุ่มเปิดเว็บ
                Button(
                    onClick = {
                        val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://nknz.xyz"))
                        context.startActivity(intent)
                    },
                    modifier = Modifier
                        .padding(horizontal = 16.dp)
                        .width(200.dp)
                        .height(60.dp)
                ) {
                    Text(
                        text = "เปิดเว็บ",
                        fontFamily = ThaiFontFamily
                    )
                }

                // ปุ่มเปิด SelfActivity
                Button(
                    onClick = {
                        val intent = Intent(context, SelfActivity::class.java)
                        context.startActivity(intent)
                    },
                    modifier = Modifier
                        .padding(top = 16.dp)
                        .width(200.dp)
                        .height(60.dp)
                ) {
                    Text(
                        text = "SelfActivity",
                        fontFamily = ThaiFontFamily
                    )
                }

                // ปุ่มเปิด FanActivity
                Button(
                    onClick = {
                        val intent = Intent(context, FanActivity::class.java)
                        context.startActivity(intent)
                    },
                    modifier = Modifier
                        .padding(top = 16.dp)
                        .width(200.dp)
                        .height(60.dp)
                ) {
                    Text(
                        text = "FanActivity",
                        fontFamily = ThaiFontFamily
                    )
                }

                // ข้อความชื่อและรหัส
                Text(
                    text = "นพกร ราชชารี",
                    style = TextStyle(
                        fontSize = 22.sp,
                        fontFamily = ThaiFontFamily
                    ),
                    modifier = Modifier.padding(top = 19.dp)
                )
                Text(
                    text = "66102122122",
                    style = TextStyle(
                        fontSize = 19.sp,
                        fontFamily = ThaiFontFamily
                    ),
                    modifier = Modifier.padding(top = 4.dp)
                )
            }
        }
    }
}

@Preview(showBackground = true)
@Composable
fun MainScreenPreview() {
    MyApplicationTheme {
        MainScreen()
    }
}
